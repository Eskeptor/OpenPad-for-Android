package com.example.eskeptor.practice_fileio;

import android.os.Environment;

import java.io.File;

/**
 * Created by eskeptor on 17. 1. 26.
 */

class Constant
{
    public static final String APP_INTERNAL_URL = Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + "Notepad";

    //public static final int FOLDER_COUNT_LIMIT = 30;
    public static final String FOLDER_DEFAULT_NAME = "Basic";
    public static final int FOLDER_TYPE_DEFAULT = 1;
    public static final int FOLDER_TYPE_CUSTOM = 2;
    public static final int FOLDER_TYPE_EXTERNAL = -1;

    public static final int MEMO_TYPE_NEW = 1;
    public static final int MEMO_TYPE_OPEN = 2;

    public static final int BROWSER_TYPE_OPEN_EXTERNAL = 1;
    public static final int BROWSER_TYPE_SAVE_EXTERNAL_NONE_OPENEDFILE = 3;
    public static final int BROWSER_MENU_SORT_ASC = 0;
    public static final int BROWSER_MENU_SORT_DES = 1;

    public static final int SELECTOR_TYPE_SAVE = 1;
    public static final int SELECTOR_TYPE_OPEN = 2;

    //public static final int REQUEST_CODE_MEMO_INDEX_CHECK = 7;
    public static final int REQUEST_CODE_SAVE_COMPLETE = 0;
    public static final int REQUEST_CODE_OPEN_COMPLETE = 1;
    public static final int REQUEST_CODE_OPEN_FILE_EXTERNAL = 2;
    public static final int REQUEST_CODE_OPEN_FOLDER = 3;

    //public static final int FILE_TYPE_LOG = 1;
    public static final int FILE_TYPE_NORMAL = 2;

    public static final String REGEX = "^[_a-zA-Z0-9.]*$";

    public static final long WAIT_FOR_SECOND = 2000L;
    public static final String FILE_EXTENSION = ".txt";

    public static final String LOG_FILE_COUNT = "lastCount.log";
    //public static final String LOG_FILE_HISTORY = "filehistory.log";
    //public static final int LOG_FILE_HISTORY_LIMIT = 20;

}
