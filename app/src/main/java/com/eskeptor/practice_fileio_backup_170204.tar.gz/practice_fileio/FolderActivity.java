package com.example.eskeptor.practice_fileio;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Space;

import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;

public class FolderActivity extends AppCompatActivity {
    private ArrayList<Folder> folders = null;

    private Context context_this;

    private int folders_length = 0;

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.anim_slide_in_right, R.anim.anim_slide_out_left);
    }

    private ListView folderList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_folder);

        context_this = getApplicationContext();

        folderList = (ListView)findViewById(R.id.folder_list) ;

        folders = new ArrayList<>();

        File file = new File(Constant.APP_INTERNAL_URL);
        File files[] = file.listFiles(new FileFilter() {
            @Override
            public boolean accept(File pathname) {
                return pathname.isDirectory();
            }
        });
        folders_length = files.length;

        for(int i = 0; i < files.length; i++)
        {
            folders.add(new Folder(files[i].getName(), files[i].listFiles(new FileFilter() {
                @Override
                public boolean accept(File pathname) {
                    return pathname.isFile() || pathname.getName().endsWith(Constant.FILE_EXTENSION);
                }
            }).length, checkFolderType(files[i]), this));
        }
        // 파일 브라우저 연결
        folders.add(new Folder("외부 파일 열기", Constant.FOLDER_TYPE_EXTERNAL, Constant.FOLDER_TYPE_EXTERNAL, null));

        FolderAdaptor adapter = new FolderAdaptor(this, folders);
        folderList.setAdapter(adapter);

        folderList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(position == folders_length)
                {
                    Intent intent = new Intent();
                    intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    intent.setClass(context_this, FileBrowser.class);
                    intent.setType("text/plain");
                    intent.putExtra("BROWSER_TYPE", Constant.BROWSER_TYPE_OPEN_EXTERNAL);
                    startActivity(intent);
                }
                else
                {
                    Intent intent = new Intent();
                    intent.putExtra("FOLDER_URL", folders.get(position).url);
                    setResult(RESULT_OK, intent);
                }
                finish();
                folders.clear();
                overridePendingTransition(R.anim.anim_slide_in_right, R.anim.anim_slide_out_left);
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        folders.clear();
    }

    private int checkFolderType(final File file)
    {
        if(file.getName().equals(Constant.FOLDER_DEFAULT_NAME))
        {
            return Constant.FOLDER_TYPE_DEFAULT;
        }
        return Constant.FOLDER_TYPE_CUSTOM;
    }
}
