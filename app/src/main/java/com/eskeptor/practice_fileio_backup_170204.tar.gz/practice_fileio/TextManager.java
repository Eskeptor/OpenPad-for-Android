package com.example.eskeptor.practice_fileio;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

/**
 * Created by eskeptor on 17. 1. 25.
 */

public class TextManager
{
    private boolean fileopen = false;
    private boolean saved = false;
    private String fileopen_name = null;

    public TextManager()
    {
        initManager();
    }

    public void initManager()
    {
        fileopen = false;
        fileopen_name = null;
        saved = false;
    }

    public boolean isSaved()
    {
        return saved;
    }

    public String getFileopen_name()
    {
        return fileopen_name;
    }

    public boolean isFileopen()
    {
        return fileopen;
    }

    public boolean saveText(final String strData, final String filename, final int type)
    {
        if(strData == null || strData.isEmpty())
        {
            return false;
        }
        FileOutputStream fos = null;
        BufferedOutputStream bos = null;
        if(type == Constant.FILE_TYPE_NORMAL)
        {
            if(isFileopen())
            {
                try
                {
                    fos = new FileOutputStream(new File(fileopen_name));
                    bos = new BufferedOutputStream(fos);
                    if(strData == null || strData.isEmpty())
                    {
                        bos.write(0);
                    }
                    else
                    {
                        bos.write(strData.getBytes());
                    }
                }
                catch (Exception e) {e.printStackTrace();}
                finally {
                    try{bos.close();}
                    catch (Exception e){e.printStackTrace();}
                    try{fos.close();}
                    catch (Exception e){e.printStackTrace();}
                }
            }
            else
            {
                try
                {
                    fos = new FileOutputStream(new File(filename));
                    bos = new BufferedOutputStream(fos);
                    if(strData == null || strData.isEmpty())
                    {
                        bos.write(0);
                    }
                    else
                    {
                        bos.write(strData.getBytes());
                    }
                }
                catch (Exception e) {e.printStackTrace();}
                finally {
                    try{bos.close();}
                    catch (Exception e){e.printStackTrace();}
                    try{fos.close();}
                    catch (Exception e){e.printStackTrace();}
                }
            }
        }
        else
        {
            try
            {
                String newstr = strData + System.getProperty("line.separator");
                fos = new FileOutputStream(new File(filename), true);
                bos = new BufferedOutputStream(fos);
                if(strData == null || strData.isEmpty())
                {
                    bos.write(0);
                }
                else
                {
                    bos.write(newstr.getBytes());
                }
            }
            catch (Exception e) {e.printStackTrace();}
            finally {
                try{bos.close();}
                catch (Exception e){e.printStackTrace();}
                try{fos.close();}
                catch (Exception e){e.printStackTrace();}
            }
        }
        saved = true;
        return true;
    }

    public String openText(final String filename)
    {
        /*if(filename != null)
        {
            FileInputStream fis = null;
            BufferedInputStream bis = null;
            try
            {
                fis = new FileInputStream(new File(filename));
                bis = new BufferedInputStream(fis);
                byte data[] = new byte[bis.available()];
                if(bis.available() != 0)
                {
                    while(bis.read(data) != -1);
                    fileopen = true;
                    fileopen_name = filename;
                    return new String(data);
                }
                else
                {
                    fileopen = false;
                    fileopen_name = null;
                }
            }
            catch (Exception e){e.printStackTrace();}
            finally {
                try{bis.close();}
                catch (Exception e){e.printStackTrace();}
                try{fis.close();}
                catch (Exception e){e.printStackTrace();}
            }
        }*/

        if(filename != null)
        {
            FileInputStream fis = null;
            FileChannel channel = null;
            ByteBuffer buffer = null;
            try
            {
                fis = new FileInputStream(new File(filename));
                channel = fis.getChannel();
                buffer = ByteBuffer.allocateDirect((int)channel.size());
                if(fis.available() != 0)
                {
                    channel.read(buffer);
                    buffer.flip();
                    fileopen = true;
                    fileopen_name = filename;
                    return new String(buffer.array());
                }
                else
                {
                    fileopen = false;
                    fileopen_name = null;
                }
            }
            catch (Exception e){e.printStackTrace();}
            finally {
                try{
                    fis.close();
                    buffer.clear();
                }
                catch (Exception e){e.printStackTrace();}
            }
        }
        return "";
    }
}
