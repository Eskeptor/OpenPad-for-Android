package com.example.eskeptor.practice_fileio;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;

import java.io.File;
import java.io.IOException;

public class MemoActivity extends AppCompatActivity {
    private String openFileURL = null;
    private String openFileName = null;
    private int memoType = 0;
    private int memoIndex = 0;

    private EditText editText = null;
    private TextManager txtManager = null;

    private File appDir = null;
    private File lastLog = null;

    private Context context_this = null;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(resultCode == RESULT_OK)
        {
            switch (requestCode)
            {
                case Constant.REQUEST_CODE_SAVE_COMPLETE:
                {
                    writeLog();
                    finish();
                    break;
                }
            }
        }
    }

    @Override
    public void onBackPressed() {
        if(isModified())
        {
            DialogInterface.OnClickListener clickListener = new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    switch (which)
                    {
                        case AlertDialog.BUTTON_POSITIVE:
                        {
                            switch (memoType)
                            {
                                case Constant.MEMO_TYPE_NEW:
                                {
                                    AlertDialog openDialog = createSeletor(Constant.SELECTOR_TYPE_SAVE).create();
                                    openDialog.show();
                                    break;
                                }
                                case Constant.MEMO_TYPE_OPEN:
                                {
                                    txtManager.saveText(editText.getText().toString(), txtManager.getFileopen_name(), Constant.FILE_TYPE_NORMAL);
                                    finish();
                                    break;
                                }
                            }
                            break;
                        }
                        case AlertDialog.BUTTON_NEGATIVE:
                        {
                            switch (memoType)
                            {
                                case Constant.MEMO_TYPE_NEW:
                                {
                                    finish();
                                    break;
                                }
                                case Constant.MEMO_TYPE_OPEN:
                                {
                                    writeLog();
                                    finish();
                                    break;
                                }
                            }
                            break;
                        }
                    }
                    dialog.dismiss();
                }
            };
            AlertDialog.Builder alert = new AlertDialog.Builder(this);
            alert.setTitle(getResources().getString(R.string.memo_alert_modified_title));
            alert.setMessage(getResources().getString(R.string.memo_alert_modified_context));
            alert.setPositiveButton(getResources().getString(R.string.memo_alert_modified_btnSave), clickListener);
            alert.setNegativeButton(getResources().getString(R.string.memo_alert_modified_btnDiscard), clickListener);
            alert.show();
        }
        else
        {
            writeLog();
            super.onBackPressed();
            overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_right);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_memo);

            context_this = getApplicationContext();

        memoType = getIntent().getIntExtra("MEMO_TYPE", Constant.MEMO_TYPE_NEW);
        editText = (EditText)findViewById(R.id.memo_etxtMain);
        txtManager = new TextManager();

        switch (memoType)
        {
            case Constant.MEMO_TYPE_NEW:
            {
                appDir = new File(Constant.APP_INTERNAL_URL);
                lastLog = new File(Constant.APP_INTERNAL_URL + File.separator + Constant.LOG_FILE_COUNT);

                if(!appDir.exists())
                {
                    appDir.mkdir();
                }
                if(!lastLog.exists())
                {
                    try
                    {
                        lastLog.createNewFile();
                        memoIndex = 1;
                        txtManager.saveText(Integer.toString(memoIndex), lastLog.getPath(), Constant.FILE_TYPE_NORMAL);
                    }
                    catch (IOException ioe){ioe.printStackTrace();}
                }
                else
                {
                    try {memoIndex = Integer.parseInt(txtManager.openText(lastLog.getPath()));}
                    catch (Exception e) {e.printStackTrace();}
                }
                txtManager.initManager();
                setTitle(getResources().getString(R.string.memo_title_newFile));
                editText.setText("");
                break;
            }
            case Constant.MEMO_TYPE_OPEN:
            {
                appDir = null;
                lastLog = null;
                openFileURL = getIntent().getStringExtra("RESULT_OPEN_FILEURL");
                openFileName = getIntent().getStringExtra("RESULT_OPEN_FILENAME");
                setTitle(openFileName);
                String txtData = txtManager.openText(openFileURL);
                editText.setText(txtData);

                Intent intent = new Intent();
                intent.putExtra("FILE_OPEN", true);
                setResult(RESULT_OK, intent);
                break;
            }
        }
    }

    private AlertDialog.Builder createSeletor(final int type)
    {
        AlertDialog.Builder openSelector = new AlertDialog.Builder(this);
        openSelector.setTitle(getResources().getString(R.string.memo_alert_save_context));
        openSelector.setItems(R.array.main_selectalert, new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case 0:
                    {
                        Intent intent = new Intent();
                        intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        intent.setClass(context_this, FileBrowser.class);
                        intent.setType("text/plain");
                        switch (type)
                        {
                            case Constant.SELECTOR_TYPE_SAVE:
                            {
                                intent.putExtra("BROWSER_TYPE", Constant.BROWSER_TYPE_SAVE_EXTERNAL_NONE_OPENEDFILE);
                                startActivityForResult(intent, Constant.REQUEST_CODE_SAVE_COMPLETE);
                                break;
                            }
                            case Constant.SELECTOR_TYPE_OPEN:
                            {
                                intent.putExtra("BROWSER_TYPE", Constant.BROWSER_TYPE_OPEN_EXTERNAL);
                                startActivityForResult(intent, Constant.REQUEST_CODE_OPEN_COMPLETE);
                                break;
                            }
                        }
                        break;
                    }
                    case 1:
                    {
                        if(txtManager.isFileopen())
                        {
                            txtManager.saveText(editText.getText().toString(), openFileURL, Constant.FILE_TYPE_NORMAL);
                        }
                        else
                        {
                            openFileURL = Constant.APP_INTERNAL_URL + File.separator + memoIndex + Constant.FILE_EXTENSION;
                            txtManager.saveText(editText.getText().toString(), openFileURL, Constant.FILE_TYPE_NORMAL);
                        }
                        memoIndex++;
                        finish();
                        break;
                    }
                }
                dialog.dismiss();
            }
        });
        return openSelector;
    }

    private boolean isModified() {
        if (memoType == Constant.MEMO_TYPE_OPEN)
        {
            if (!editText.getText().toString().equals(txtManager.openText(txtManager.getFileopen_name()))) {return true;}
        }
        else
        {
            if (!editText.getText().toString().equals("")) {return true;}
        }
        return false;
    }

    private void writeLog()
    {
        try {
            if(!txtManager.isFileopen())
            {
                txtManager.saveText(Integer.toString(memoIndex), lastLog.getPath(), Constant.FILE_TYPE_NORMAL);
                // 최근 리스트는 추후 업데이트 예정
                /*if(txtManager.isSaved()) {
                    setResult(RESULT_OK);
                }*/
            }
            else
            {
                // 최근 리스트는 추후 업데이트 예정
                //setResult(RESULT_OK);
            }
        }
        catch(Exception e){e.printStackTrace();}
    }

}
