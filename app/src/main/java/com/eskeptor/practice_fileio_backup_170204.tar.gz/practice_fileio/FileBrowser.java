package com.example.eskeptor.practice_fileio;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Created by eskeptor on 17. 1. 26.
 */

public class FileBrowser extends AppCompatActivity
{
    private TextView txtPath = null;
    private ListView lvFilecontrol = null;
    private Spinner menu_spinner = null;
    private LinearLayout saveLayout = null;
    private Button btnSave = null;
    private EditText etxtSave = null;

    private String str_filename = null;
    private String str_root = null;

    private List<String> list_item = null;
    private List<String> list_path = null;

    private int browserType = 0;
    private int sortType = 0;

    private Pattern pattern = null;

    private Context context_this = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filebrowser);

        context_this = getApplicationContext();

        browserType = getIntent().getIntExtra("BROWSER_TYPE", 0);
        str_root = Environment.getExternalStorageDirectory().getAbsolutePath();
        sortType = Constant.BROWSER_MENU_SORT_ASC;

        txtPath = (TextView)findViewById(R.id.browser_txtPath);
        lvFilecontrol = (ListView)findViewById(R.id.browser_lvFilecontrol);
        saveLayout = (LinearLayout)findViewById(R.id.browser_saveLayout);
        etxtSave = (EditText)findViewById(R.id.browser_etxtSave);
        switch (browserType)
        {
            case Constant.BROWSER_TYPE_OPEN_EXTERNAL:
            {
                setTitle(getResources().getString(R.string.browser_name_open));
                saveLayout.setVisibility(View.GONE);
                break;
            }
            case Constant.BROWSER_TYPE_SAVE_EXTERNAL_NONE_OPENEDFILE:
            {
                setTitle(getResources().getString(R.string.browser_name_save));
                saveLayout.setVisibility(View.VISIBLE);
                btnSave = (Button)findViewById(R.id.browser_btnSave);
                break;
            }
        }

        getDirectory(str_root);

        lvFilecontrol.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                File file = new File(list_path.get(position));

                if(file.isDirectory())
                {
                    if(file.canRead())
                    {
                        getDirectory(list_path.get(position));
                    }
                }
                else if(file.isFile())
                {
                    Intent intent = new Intent();

                    intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    intent.setClass(context_this, MemoActivity.class);
                    intent.putExtra("RESULT_OPEN_FILEURL", list_path.get(position));
                    intent.putExtra("RESULT_OPEN_FILENAME", file.getName());
                    intent.putExtra("MEMO_TYPE", Constant.MEMO_TYPE_OPEN);
                    startActivity(intent);
                    finish();
                }
            }
        });
    }

    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.browser_btnSave:
            {
                pattern = Pattern.compile(Constant.REGEX);
                if(!etxtSave.getText().toString().equals("") && pattern.matcher(etxtSave.getText().toString()).matches())
                {
                    Intent intent = new Intent();
                    intent.putExtra("RESULT_SAVE_FOLDER_URL", str_filename + File.separator);
                    intent.putExtra("RESULT_SAVE_FILE_URL", etxtSave.getText().toString());
                    setResult(RESULT_OK, intent);
                    finish();
                }
                else
                {
                    Toast.makeText(this, getResources().getString(R.string.browser_toast_error_regex), Toast.LENGTH_SHORT).show();
                    etxtSave.setText("");
                }
                break;
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (str_filename.equals(str_root))
        {
            super.onBackPressed();
        }
        else
        {
            getDirectory(list_path.get(list_item.indexOf("../")));
        }
    }

    public void getDirectory(final String dir)
    {
        list_item = new ArrayList<>();
        list_path = new ArrayList<>();

        File file = new File(dir);
        File files[];
        if(browserType == Constant.BROWSER_TYPE_OPEN_EXTERNAL)
        {
            files = file.listFiles(new FileFilter() {
                @Override
                public boolean accept(File pathname) {
                    String name = pathname.getName();
                    return pathname.isDirectory() || name.endsWith(Constant.FILE_EXTENSION);
                }
            });
        }
        else if(browserType == Constant.BROWSER_TYPE_SAVE_EXTERNAL_NONE_OPENEDFILE)
        {
            files = file.listFiles(new FileFilter() {
                @Override
                public boolean accept(File pathname) {
                    Log.i("accept", pathname.getName() + " : " + Boolean.toString(pathname.isDirectory()));
                    return pathname.isDirectory();
                }
            });
        }
        else
        {
            files = null;
        }

        if(!dir.equals(str_root))
        {
            list_item.add("../");
            list_path.add(file.getParent());
        }
        for(int i = 0; i < files.length; i++)
        {
            File tmp = files[i];
            list_path.add(tmp.getAbsolutePath());
            if(tmp.isDirectory())
            {
                list_item.add(tmp.getName() + File.separator);
            }
            else
            {
                list_item.add(tmp.getName());
            }
        }

        switch (sortType)
        {
            case Constant.BROWSER_MENU_SORT_ASC:
            {
                Collections.sort(list_item);
                Collections.sort(list_path);
                break;
            }
            case Constant.BROWSER_MENU_SORT_DES:
            {
                Collections.reverse(list_item);
                Collections.reverse(list_path);
                break;
            }
        }

        txtPath.setText(getResources().getString(R.string.browser_Location) + " " + dir);
        ArrayAdapter<String> filelist = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list_item);
        lvFilecontrol.setAdapter(filelist);
        str_filename = dir;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_filebrowser, menu);
        MenuItem item = menu.findItem(R.id.menu_spinner);
        menu_spinner = (Spinner) MenuItemCompat.getActionView(item);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.menu_spinner_sort, R.layout.spinner_layout);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        menu_spinner.setAdapter(adapter);
        menu_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position)
                {
                    case Constant.BROWSER_MENU_SORT_ASC:
                    {
                        sortType = Constant.BROWSER_MENU_SORT_ASC;
                        getDirectory(str_filename);
                        break;
                    }
                    case Constant.BROWSER_MENU_SORT_DES:
                    {
                        sortType = Constant.BROWSER_MENU_SORT_DES;
                        getDirectory(str_filename);
                        break;
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        return true;
    }
}
