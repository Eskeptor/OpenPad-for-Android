package com.example.eskeptor.practice_fileio;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import java.io.File;
import java.io.FileFilter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private long backPressedTime = 0;
    private TextManager txtManager = null;

    //private String urlLog = null;
    private String curFolderURL = null;

    private GridView curFolderGridView = null;
    private TextFileAdaptor curFileAdapter = null;
    private ArrayList<TextFile> curFolderFileList = null;

    public Context context_this = null;

    // 최근 리스트는 추후 업데이트 예정
    /*private ArrayList<String> list_item;
    private ArrayList<String> list_path;
    private Bundle list_data;*/
    /*private void lastFileListCreator()
    {
        File file = new File(Constant.APP_INTERNAL_URL + File.separator + Constant.LOG_FILE_HISTORY);
        BufferedReader br = null;
        String line = null;
        if(file.exists())
        {
            try
            {
                br = new BufferedReader(new FileReader(file));
                while((line = br.readLine()) != null)
                {
                    if(!list_path.contains(line))
                    {
                        list_item.add(line);
                        list_path.add(line);
                    }
                }
            }
            catch (Exception e){e.printStackTrace();}
            finally
            {
                try{br.close();}
                catch (Exception e){e.printStackTrace();}
            }
        }
    }*/

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(resultCode == RESULT_OK)
        {
            switch (requestCode)
            {
                /*case Constant.REQUEST_CODE_OPEN_FILE_EXTERNAL:
                {
                    Intent intent = new Intent();
                    urlLog = data.getStringExtra("RESULT_OPEN_FILEURL");
                    intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    intent.setClass(this, MemoActivity.class);
                    intent.putExtra("RESULT_OPEN_FILEURL", urlLog);
                    intent.putExtra("RESULT_OPEN_FILENAME", data.getStringExtra("RESULT_OPEN_FILENAME"));
                    intent.putExtra("MEMO_TYPE", Constant.MEMO_TYPE_OPEN);
                    startActivity(intent);
                    //startActivityForResult(intent, Constant.REQUEST_CODE_OPEN_COMPLETE);
                    break;
                }*/
                case Constant.REQUEST_CODE_OPEN_FOLDER:
                {
                    curFolderURL = data.getStringExtra("FOLDER_URL");
                    curFolderFiles();
                    curFileAdapter.notifyDataSetChanged();
                    break;
                }
                // 최근 리스트는 추후 업데이트 예정
                /*case Constant.REQUEST_CODE_OPEN_COMPLETE:
                {

                    writeLog();
                    break;
                }*/
            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id)
        {
            /*case R.id.menu_main_open:
            {
                Intent intent = new Intent();
                intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                intent.setClass(this, FileBrowser.class);
                intent.setType("text/plain");
                intent.putExtra("BROWSER_TYPE", Constant.BROWSER_TYPE_OPEN_EXTERNAL);
                startActivity(intent);

                return true;
            }*/
            case android.R.id.home:
            {
                Intent intent = new Intent();
                intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                intent.setClass(this, FolderActivity.class);
                startActivityForResult(intent, Constant.REQUEST_CODE_OPEN_FOLDER);
                overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_right);
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 최근 리스트는 추후 업데이트 예정
        /*list_item = new ArrayList<>();
        list_path = new ArrayList<>();
        list_data = new Bundle();*/

        context_this = getApplicationContext();

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_folder_open_white);

        curFolderGridView = (GridView)findViewById(R.id.main_curFolderFileList);
        curFolderFileList = new ArrayList<>();

        // 최근 리스트는 추후 업데이트 예정
        /*lastFileListCreator();
        list_data.putStringArrayList("LIST_ITEM", list_item);
        list_data.putStringArrayList("LIST_PATH", list_path);*/

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.main_add);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                intent.setClass(context_this, MemoActivity.class);
                intent.putExtra("MEMO_TYPE", Constant.MEMO_TYPE_NEW);
                startActivity(intent);
                overridePendingTransition(R.anim.anim_slide_in_right, R.anim.anim_slide_out_left);

                // 최근 리스트는 추후 업데이트 예정
                // startActivityForResult(intent, Constant.REQUEST_CODE_OPEN_COMPLETE);
            }
        });

        txtManager = new TextManager();
        defaultFolderCheck();
        curFolderFiles();

        curFileAdapter = new TextFileAdaptor(this, curFolderFileList);
        curFolderGridView.setAdapter(curFileAdapter);
        curFolderGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent();
                intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                intent.setClass(context_this, MemoActivity.class);
                intent.putExtra("RESULT_OPEN_FILEURL", curFolderFileList.get(position).url);
                intent.putExtra("RESULT_OPEN_FILENAME", curFolderFileList.get(position).title);
                intent.putExtra("MEMO_TYPE", Constant.MEMO_TYPE_OPEN);
                startActivity(intent);
                overridePendingTransition(R.anim.anim_slide_in_right, R.anim.anim_slide_out_left);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        curFolderFiles();
        curFileAdapter.notifyDataSetChanged();
    }

    @Override
    public void onBackPressed() {
        long tempTime = System.currentTimeMillis();
        long intervalTime = tempTime - backPressedTime;

        if(0 <= intervalTime && Constant.WAIT_FOR_SECOND >= intervalTime)
        {
            super.onBackPressed();
        }
        else
        {
            backPressedTime = tempTime;
            Toast.makeText(this, getResources().getString(R.string.back_press), Toast.LENGTH_SHORT).show();
        }
    }

    private void defaultFolderCheck()
    {
        File file = new File(Constant.APP_INTERNAL_URL);
        if(!file.exists())
        {
            file.mkdir();
        }
        file = new File(Constant.APP_INTERNAL_URL + File.separator+ Constant.FOLDER_DEFAULT_NAME);
        if(!file.exists())
        {
            file.mkdir();
        }
        curFolderURL = file.getPath();
        Log.d("Debug", "defaultFolderCheck : " + curFolderURL);
    }

    private void curFolderFiles()
    {
        File file = new File(curFolderURL);
        File files[] = file.listFiles(new FileFilter() {
            @Override
            public boolean accept(File pathname) {
                return pathname.getName().endsWith(Constant.FILE_EXTENSION);
            }
        });
        curFolderFileList.clear();
        for(int i = 0; i < files.length; i++)
        {
            curFolderFileList.add(new TextFile(files[i], getResources().getString(R.string.file_noname), new SimpleDateFormat(getResources().getString(R.string.file_dateformat))));
        }
    }

    // 최근 리스트는 추후 업데이트 예정
    /*private void writeLog()
    {
        File file = new File(Constant.APP_INTERNAL_URL + File.separator + Constant.LOG_FILE_HISTORY);
        BufferedReader br = null;
        boolean check = true;
        String line = null;
        try
        {
            br = new BufferedReader(new FileReader(file));
            while((line = br.readLine()) != null)
            {
                if(line.equals(urlLog))
                {
                    check = false;
                    break;
                }
            }
            if(check)
            {
                txtManager.saveText(urlLog, Constant.APP_INTERNAL_URL + File.separator + Constant.LOG_FILE_HISTORY, Constant.FILE_TYPE_LOG);
            }
        }
        catch (Exception e){e.printStackTrace();}
        finally
        {
            try{br.close();}
            catch (Exception e){e.printStackTrace();}
        }
    }*/
}
