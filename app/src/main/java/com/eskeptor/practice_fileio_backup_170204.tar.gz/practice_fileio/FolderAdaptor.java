package com.example.eskeptor.practice_fileio;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by eskeptor on 17. 2. 2.
 */

public class FolderAdaptor extends BaseAdapter {
    private Context context = null;
    private ArrayList<Folder> folders = null;
    private LayoutInflater layoutInflater = null;

    public FolderAdaptor(final Context context, final ArrayList<Folder> folders)
    {
        this.context = context;
        this.folders = folders;
        layoutInflater = LayoutInflater.from(this.context);
    }

    @Override
    public int getCount() {
        return folders.size();
    }

    @Override
    public Object getItem(int position) {
        return folders.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View itemLayout = layoutInflater.inflate(R.layout.item_folder_layout, null);
        ImageView folderImage = (ImageView)itemLayout.findViewById(R.id.item_folder_image);
        TextView txtName = (TextView)itemLayout.findViewById(R.id.item_folder_name);
        TextView txtCount = (TextView)itemLayout.findViewById(R.id.item_folder_count);

        if(folders.get(position).type == Constant.FOLDER_TYPE_DEFAULT)
        {
            folderImage.setImageResource(R.drawable.ic_folder_shared_black_24dp);
        }
        else
        {
            folderImage.setImageResource(R.drawable.ic_folder_open_black);
        }
        txtName.setText(folders.get(position).name);
        if(folders.get(position).count == -1)
        {
            txtCount.setText("");
        }
        else
        {
            txtCount.setText(Integer.toString(folders.get(position).count));
        }

        return itemLayout;
    }
}
