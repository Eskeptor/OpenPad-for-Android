package com.example.eskeptor.practice_fileio;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by eskeptor on 17. 2. 4.
 */

public class TextFileAdaptor extends BaseAdapter {
    private Context context = null;
    private ArrayList<TextFile> textFiles = null;
    private LayoutInflater layoutInflater = null;

    public TextFileAdaptor(final Context context, final ArrayList<TextFile> textFiles)
    {
        this.context = context;
        this.textFiles = textFiles;
        layoutInflater = LayoutInflater.from(this.context);
    }

    @Override
    public int getCount() {
        return textFiles.size();
    }

    @Override
    public Object getItem(int position) {
        return textFiles.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View itemLayout = layoutInflater.inflate(R.layout.item_file_layout, null);
        TextView txtTitle = (TextView)itemLayout.findViewById(R.id.item_file_title);
        TextView txtContext = (TextView)itemLayout.findViewById(R.id.item_file_context);
        TextView txtDate = (TextView)itemLayout.findViewById(R.id.item_file_date);

        txtTitle.setText(textFiles.get(position).title);
        txtContext.setText(textFiles.get(position).context_oneline);
        txtDate.setText(textFiles.get(position).date);
        return itemLayout;
    }
}
